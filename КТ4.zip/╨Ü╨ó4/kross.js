function toggleMenu() {
  const header = document.querySelector('.header');
  header.classList.toggle('active');
  }
  